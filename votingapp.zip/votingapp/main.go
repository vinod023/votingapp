package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"
	"votingapp/models"
	"votingapp/util"

	"github.com/gorilla/handlers"

	"github.com/gorilla/mux"
	"github.com/jinzhu/gorm"

	"github.com/lib/pq"
)

//App define the gorm and gorilla mux
type App struct {
	Router *mux.Router
	DB     *gorm.DB
}

func main() {

	config := App{}
	config.initialize()
	http.Handle("/", config.Handlers())

	log.Fatal(http.ListenAndServe(":8000", handlers.CORS(handlers.AllowedHeaders([]string{"X-Requested-With", "Content-Type", "Authorization"}),
		handlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE"}), handlers.AllowedOrigins([]string{"*"}))(config.Router)))
}

func (app *App) initialize() {
	dbURI := fmt.Sprintf("dbname=%s host=%s port=%s user=%s  password=%s  sslmode=disable",
		"votingapp", "127.0.0.1", "5432", "postgres", "postgres")

	db, err := gorm.Open("postgres", dbURI)

	if err != nil {
		log.Fatal("Could not connect database", err)
	}
	db.DB().SetMaxIdleConns(2)
	db.DB().SetMaxOpenConns(100)
	db.DB().SetConnMaxLifetime(5 * time.Minute)

	app.DB = db
}

//Handlers for URLs
func (app *App) Handlers() *mux.Router {

	app.Router = mux.NewRouter().StrictSlash(true)
	app.Router.HandleFunc("/login", app.userLogin).Methods("POST")
	app.Router.HandleFunc("/candidates", app.candidates).Methods("GET")
	app.Router.HandleFunc("/vote", app.vote).Methods("POST")
	app.Router.HandleFunc("/votes", app.votes).Methods("GET")

	return app.Router
}

//userLogin controller
func (app *App) userLogin(ResponseWriter http.ResponseWriter, Request *http.Request) {
	var login models.Login
	err := json.NewDecoder(Request.Body).Decode(&login)
	if err != nil {
		util.RespondError(ResponseWriter, http.StatusBadRequest, errors.New("Input data is not in correct format").Error())
		return
	}
	//Right now I am directly storing password as string. But in real time development we need to follow the encrytion format.
	userID, roleID, err := checkUserLogin(app.DB, login)
	if err != nil || userID == 0 {
		util.RespondError(ResponseWriter, http.StatusNotFound, errors.New("Invalid Email/Password").Error())
		return
	}
	response := map[string]interface{}{
		"message": "Login Success",
		"roleId":  roleID,
		"userId":  userID,
	}
	util.RespondJSON(ResponseWriter, http.StatusOK, response)
}

//candidates controller
func (app *App) candidates(ResponseWriter http.ResponseWriter, Request *http.Request) {
	userID, _ := strconv.Atoi(Request.FormValue("userId"))
	if userID == 0 {
		util.RespondError(ResponseWriter, http.StatusBadRequest, errors.New("Invalid userId").Error())
		return
	}

	candidates, err := getCandidates(app.DB)
	if err != nil {
		util.RespondError(ResponseWriter, http.StatusNotFound, errors.New("No records found").Error())
		return
	}
	util.RespondJSON(ResponseWriter, http.StatusOK, candidates)
}

//vote controller
func (app *App) vote(ResponseWriter http.ResponseWriter, Request *http.Request) {
	userID, _ := strconv.Atoi(Request.FormValue("userId"))
	candidateID, _ := strconv.Atoi(Request.FormValue("candidateId"))
	if userID == 0 || candidateID == 0 {
		util.RespondError(ResponseWriter, http.StatusBadRequest, errors.New("Invalid userId/candidateId").Error())
		return
	}

	isExists, err := isVoteExists(app.DB, userID)
	if err != nil {
		util.RespondError(ResponseWriter, http.StatusNotFound, errors.New("No records found").Error())
		return
	}
	if isExists {
		util.RespondJSON(ResponseWriter, http.StatusOK, "You already done the voting")
		return
	}

	currentTime := time.Now()
	votingResults := models.VotingResults{
		UserID:      userID,
		CandidateID: candidateID,
		CreatedAt:   currentTime,
		Updatedat:   currentTime,
	}
	err = insertVote(app.DB, votingResults)
	if err != nil {
		util.RespondError(ResponseWriter, http.StatusInternalServerError, err.Error())
		return
	}

	util.RespondJSON(ResponseWriter, http.StatusOK, "Voting Success")
}

//votes controller
func (app *App) votes(ResponseWriter http.ResponseWriter, Request *http.Request) {
	userID, _ := strconv.Atoi(Request.FormValue("userId"))
	if userID == 0 {
		util.RespondError(ResponseWriter, http.StatusBadRequest, errors.New("Invalid userId").Error())
		return
	}

	candidateVotes, err := getVotes(app.DB, userID)
	if err != nil || len(candidateVotes) == 0 {
		util.RespondError(ResponseWriter, http.StatusNotFound, errors.New("No records found").Error())
		return
	}
	util.RespondJSON(ResponseWriter, http.StatusOK, candidateVotes)
}

func checkUserLogin(DB *gorm.DB, login models.Login) (int, int, error) {

	user := struct {
		UserID int `gorm:"column:id"`
		RoleID int `gorm:"column:roleid"`
	}{}
	query := "select id,roleid from users where email=$1 and password=$2"
	if err := DB.Raw(query, login.Email, login.Password).Scan(&user).Error; err != nil {
		return 0, 0, err
	}

	return user.UserID, user.RoleID, nil
}

func getCandidates(DB *gorm.DB) (candidate []models.Candidate, err error) {

	if err = DB.Table("candidates").Select("id,candidatename").Scan(&candidate).Error; err != nil {
		return nil, err
	}
	return candidate, nil
}

func isVoteExists(DB *gorm.DB, userID int) (bool, error) {

	isExist := struct {
		Exists bool `gorm:"column:exists"`
	}{}
	if err := DB.Raw("select exists(select id from votingresults where userid=$1)", userID).Scan(&isExist).Error; err != nil {
		return false, err
	}
	return isExist.Exists, nil
}

func insertVote(DB *gorm.DB, votingResults models.VotingResults) error {

	if err := DB.Create(&votingResults).Error; err != nil {
		pqErr := err.(*pq.Error)
		if pqErr.Code == "23503" { //postgres foreign key constraint error
			return errors.New("Invalid userId / CandidateId")
		}
		return err
	}
	return nil
}

func getVotes(DB *gorm.DB, userID int) (candidateVotes []models.Votes, err error) {

	query := `select a.id as candidateid,a.candidatename,count(b.userid) as candidatevotes from 
			  (select id,candidatename from candidates) as a
			  left join
			  (select candidateid,userid from votingresults) as b on a.id=b.candidateid 
			  join
			  users as c on c.id=$1 and roleid=1
			  group by a.candidatename,a.id order by candidatevotes desc`

	if err = DB.Raw(query, userID).Scan(&candidateVotes).Error; err != nil {
		return nil, err
	}
	return candidateVotes, nil
}
