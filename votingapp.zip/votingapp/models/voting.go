package models

import "time"

//Login - for user login
type Login struct {
	Email    string `gorm:"column:email" json:"email"`
	Password string `gorm:"column:password" json:"password"`
}

//Candidate model
type Candidate struct {
	CandidateID   int    `gorm:"column:id" json:"CandidateId"`
	CandidateName string `gorm:"column:candidatename" json:"candidateName"`
}

//VotingResults model
type VotingResults struct {
	ID          int       `gorm:"primary_key;column:id" json:"id"`
	UserID      int       `gorm:"column:userid" json:"userId"`
	CandidateID int       `gorm:"column:candidateid" json:"candidateId"`
	CreatedAt   time.Time `gorm:"column:createdat" json:"-"`
	Updatedat   time.Time `gorm:"column:updatedat" json:"-"`
}

//Votes model
type Votes struct {
	CandidateID    int    `gorm:"column:candidateid" json:"candidateId"`
	CandidateName  string `gorm:"column:candidatename" json:"candidateName"`
	CandidateVotes int    `gorm:"column:candidatevotes" json:"candidateVotes"`
}

//TableName method for VotingResults model
func (VotingResults) TableName() string {
	return "votingresults"
}
